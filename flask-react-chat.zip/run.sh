#!/bin/bash

pip install -r ./requirements.txt
echo 'starting server'
python ./server.py